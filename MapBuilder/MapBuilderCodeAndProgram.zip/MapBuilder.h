#pragma once
int** buildMap(const int);